﻿namespace CommunityEngagementAPI.Models.DTOs
{
    public class VerifyOtpDto
    {
        public string Email { get; set; }
        public string Otp { get; set; }
    }
}
